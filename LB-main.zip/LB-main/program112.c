#include<stdio.h>
int main(int argc, char **argv)
{
    int Arr[5] = { 10,20,30,40,50};

    printf("%d\n", Arr[0]);
    
    printf("%d\n", Arr[1]);
    
    printf("%d\n", Arr[2]);
    
    printf("%d\n", Arr[3]);
    
    printf("%d\n", Arr[4]);

    return 0;

}