//Interview question 
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct node
{
    int data;
    struct node *next;
};

typedef struct node NODE;
typedef struct node* PNODE;
typedef struct node** PPNODE;

void InsertFirst(PPNODE First, int No)
{
    PNODE newn = NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn->data = No;
    newn->next = NULL;

    if(*First == NULL)
    {
        *First = newn;
    }
    else
    {
        newn->next = *First;
        *First = newn;
    }
}   

void Display(PNODE First)
{
    while(First != NULL)
    {
        printf("| %d |->",First->data);
        First = First -> next;
    }
    printf("NULL\n");
} 

int Count(PNODE First)
{
    int iCnt = 0;

    while(First != NULL)
    {
        iCnt++;
        First = First -> next;
    }
    return iCnt;
} 


int Addition(PNODE First)
{
    int iSum = 0;
    while(First != NULL)
    {
        iSum = iSum + (First->data);
        First = First -> next;
    }
    return iSum;

}

int EvenCount(PNODE First)
{
    int iCount = 0;
    while(First != NULL)
    {
        if ((First ->data)%2 == 0)
        {
            iCount++;
        }
        First = First -> next;
    }
    return iCount;
}

int OddCount(PNODE First)
{
    int iCount = 0;
    while(First != NULL)
    {
        if ((First ->data)%2 != 0)
        {
            iCount++;
        }
        First = First -> next;
    }
    return iCount;
}

int Frequency(PNODE First, int No) {
    int iCount = 0;
    while (First != NULL) {
        if (First->data == No) {
            iCount++;
        }
        First = First->next;
    }
    return iCount;
}


bool Search (PNODE First,int No) 
{
    bool bFlag = false;
    while (First != NULL)
    {
        if (First->data == No)
        {
            bFlag = true;
            break;
        }
        First = First->next;
    }
    return bFlag;

}


int SearchFirstOccurance(PNODE First,int No)
{
    int iCount = 1;
    int iPos =- -1;
    while (First != NULL)
    {
        if (First->data == No)
        {
            iPos = iCount;
            break;

        }
        iCount++;
        First = First->next;
    }
   

}

int SearchLastOccurance(PNODE First, int No) {
    int iCount = 1;
    int iPos = -1;  // Initialize iPos to -1 to indicate no occurrence found initially

    while (First != NULL) {
        if (First->data == No) {
            iPos = iCount;  // Update iPos with the current position
        }
        iCount++;
        First = First->next;
    }

    return iPos;  // Return the last found position, or -1 if not found
}




void SumDigits(PNODE First)
{
    int iSum = 0;
    int iNo = 0;
    int iDigits = 0;
    while (First != NULL)
    {
        iNo = First->data;
        while (iNo != 0)
        {
            iDigits = iNo % 10;
            iSum = iSum + iDigits;
            iNo = iNo / 10;
        }
        printf("%d\n",iSum);
        iSum = 0;
        First = First->next;
    }

}

// Function to find the sum of factors of a number
int FactorsAddition(int iNo) {
    int iSum = 0, i = 0;

    for (i = 1; i <= iNo / 2; i++) {
        if (iNo % i == 0) {
            iSum = iSum + i;
        }
    }
    return iSum;
}

// Function to print the sum of factors of each element in the list
void SumFactors(PNODE First) {
    int iNo, iSum;

    while (First != NULL) {
        iNo = First->data;
        iSum = FactorsAddition(iNo);
        printf("Sum of factors of %d is: %d\n", iNo, iSum);
        First = First->next;
    }
}


bool CheckPerfect(int iNo) {
    int iSum = 0, i = 0;

    for (i = 1; i <= iNo / 2; i++) {
        if (iNo % i == 0) {
            iSum = iSum + i;
        }
    }
    if(iSum == iNo)
    {
        return true;

    }
    else{
        return false;
    }
}
void DisplayPerfect(PNODE First) {
    while (First != NULL) {
        if (CheckPerfect(First->data)) {
            printf("Perfect Number is: %d\n", First->data);
        }
        
        First = First->next;
    }
}

int main()
{
    PNODE Head = NULL;
    int iRet = 0;
    bool bRet = false;
    
    InsertFirst(&Head,42);
    //InsertFirst(&Head,6);
    InsertFirst(&Head,10);
    InsertFirst(&Head,50);
    InsertFirst(&Head,21);
    InsertFirst(&Head,10);
    InsertFirst(&Head,21);
    InsertFirst(&Head,11);
    
    Display(Head);

    DisplayPerfect(Head);


    
    return 0;
}
