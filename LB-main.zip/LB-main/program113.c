#include<stdio.h>
int main(int argc, char **argv)
{
    int i = 0;
    int Arr[5] = { 10,20,30,40,50};
    for (int i = 0; i < 5; i++)
    {
        printf("%d\n", Arr[i]);
    }

    return 0;

}