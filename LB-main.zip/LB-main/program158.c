#include<stdio.h>

int main()
{
    char Arr[] = "Hello";

    printf("%s\n",Arr);

    printf("%c\n",Arr[0]);
    printf("%c\n",Arr[1]);
    printf("%c\n",Arr[2]);
    printf("%c\n",Arr[3]);
    printf("%c\n",Arr[4]);

    return 0;
}