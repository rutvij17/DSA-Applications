
#include<iostream>
using namespace std;
int main()
{
    cout<<"Jay Ganesh \n";
    return 0;

}