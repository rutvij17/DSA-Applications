#include<stdio.h>
#include<stdlib.h>
typedef struct node 
{
    int data ;
    struct node *next;
}NODE, *PNODE,**PNODE;



int main(int argc, char **argv)
{
    PNODE Head = NULL;



    return 0;
     

}