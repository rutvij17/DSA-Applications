#include <iostream>
using namespace std;
//Approch 2 using while loop
void Display()
{
    int i = 1;
    while (i<= 4)
    {
        cout<<"*"<<endl;
        i++;

    }
}
int main()
{
    Display();
    return 0;

}