#include<stdio.h>

void Display()
{
    printf("Jay Hanuman...\n");
    printf("Jay Hanuman...\n");
    printf("Jay Hanuman...\n");
    printf("Jay Hanuman...\n");
    printf("Jay Hanuman...\n"); 
}

int main()
{
    Display();         

    return 0;
}