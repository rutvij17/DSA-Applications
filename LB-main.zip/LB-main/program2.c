//accept 2 numbers from user and perform their addition
#include <stdio.h>
int main() 
{
    int i,j, k;
    printf ("Enter first no : \n");
    scanf("%d",&i);

    printf("Enter second no :\n");
    scanf("%d",&j);

    k = i + j ;
    printf("Addition of 2 numbers is : %d\n",k);



    

    return 0;
}