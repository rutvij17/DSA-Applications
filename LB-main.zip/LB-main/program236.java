class program236
{
    public static void main(String A[])
    {
        int Arr[] = {10,20,30,40};

        System.out.println("Number of elements in Arr : "+Arr.length);
    }
}