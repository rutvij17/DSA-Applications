public class program679 {
    public static void main(String[] args) {
        System.out.println("Jay Ganesh Jay Gajanan...");
    }
    
}
