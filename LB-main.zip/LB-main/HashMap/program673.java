import java.util.*;
public class program673 {
    public static void main(String[] args) {
        
            Scanner sobj = new Scanner(System.in);
            System.out.println("Enter string :");
            String str = sobj.nextLine();
            str = str.trim();
            str = str.replaceAll("\\s+"," ");
            System.out.println(str);

           
    

}
}


//put(key,Value)
//get(key,Value)
//containsKey(key)