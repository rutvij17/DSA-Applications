#include<stdio.h>

int main()
{
    char Arr[] = "Hello";

    printf("%s\n",Arr);

    return 0;
}