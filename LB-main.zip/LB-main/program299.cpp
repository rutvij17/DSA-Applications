#include<iostream>
using namespace std;

int main()
{
    char Arr[30];

    cout<<"Enter string : "<<endl;

    cin.getline(Arr,30);

    cout<<"Entered string is : "<<Arr<<endl;
    
    return 0;
}