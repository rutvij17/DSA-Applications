class program197
{
    public static void main(String A[])
    {
        System.out.println("jay Ganesh");
    }
}