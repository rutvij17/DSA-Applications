#include <stdio.h>
int main ()
{
    printf ("Jay Ganesh .....\n");
    printf("Jay Gajanan .....\n");
    return 0;
}