import java.util.*;

class program502
{
    public static void main(String Arg[])
    {
        Scanner sobj = new Scanner(System.in);

        System.out.println("------- Marvellous Packer Unpacker CUI Module -------");

        System.out.println("Enter File name : ");
        String File_Name = sobj.nextLine();

        System.out.println("Entered file name is : "+File_Name);
    }
}