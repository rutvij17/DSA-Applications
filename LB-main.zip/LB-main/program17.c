#include<stdio.h>

int main()
{
    printf("Jay Hanuman...\n");
    printf("Jay Hanuman...\n");
    printf("Jay Hanuman...\n");
    printf("Jay Hanuman...\n");
    printf("Jay Hanuman...\n");            

    return 0;
}


