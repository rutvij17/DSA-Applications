#include<stdio.h>

int main()
{
    char ch;

    printf("Enter one character : \n");
    scanf("%c",&ch);

    printf("Entered chracter is : %c\n",ch);

    return 0;
}