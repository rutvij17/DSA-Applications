class program640
{
    public static void main(String Arg[])
    {
        System.out.println("-------- Marvellous Database Management System --------");

    }
}